# IGHG2 worked example

Saved CSV results and figures used in the MimicryMap walkthrough. IL10 compares with Curated Viral Proteomes (120) at 5/9 and 7/9; IGHG2 compares with the human proteome at 8/9. Files retain their original result values. manifest.json records SHA-256 hashes.
